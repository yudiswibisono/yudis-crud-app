

<?php $__env->startSection('content'); ?>

<div class="card">
	<div class="card-header">Edit Products</div>
	<div class="card-body">
		<form method="post" action="<?php echo e(route('products.update', $product->id)); ?>" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
			<?php echo method_field('PUT'); ?>
			<div class="row mb-3">
				<label class="col-sm-2 col-label-form">Product Name</label>
				<div class="col-sm-10">
					<input type="text" name="product_name" class="form-control" value="<?php echo e($product->product_name); ?>" />
				</div>
			</div>
			<div class="row mb-3">
				<label class="col-sm-2 col-label-form">Product Description</label>
				<div class="col-sm-10">
					<input type="text" name="product_description" class="form-control" value="<?php echo e($product->product_description); ?>" />
				</div>
			</div>
			<div class="row mb-4">
				<label class="col-sm-2 col-label-form">Product Price</label>
				<div class="col-sm-10">
					<input type="text" name="product_price" class="form-control" value="<?php echo e($product->product_price); ?>" />
				</div>
			</div>
			<div class="row mb-4">
				<label class="col-sm-2 col-label-form">Product Image</label>
				<div class="col-sm-10">
					<input type="file" name="product_image" />
					<br />
					<img src="<?php echo e(asset('images/' . $product->product_image)); ?>" width="100" class="img-thumbnail" />
					<input type="hidden" name="hidden_product_image" value="<?php echo e($product->product_image); ?>" />
				</div>
			</div>
			<div class="text-center">
				<input type="hidden" name="hidden_id" value="<?php echo e($product->id); ?>" />
				<input type="submit" class="btn btn-primary" value="Edit" />
			</div>	
		</form>
	</div>
</div>
<script>
// document.getElementsByName('product_price')[0].value = "<?php echo e($product->product_price); ?>";
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp8\htdocs\yudis-crud-app\resources\views/edit.blade.php ENDPATH**/ ?>